<?php
$host = "localhost";
$tableprefix = "toko"; //You can change this table prefix, don't use white spaces, use underscores instead for example this_is_my_table_prefix_
$databasename = "toko";
$dbuser = "root";
$dbpassword = "";